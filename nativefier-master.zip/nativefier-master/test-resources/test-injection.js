const log = require('loglevel'); // eslint-disable-line @typescript-eslint/no-var-requires

log.info('This is a test injecton script');
